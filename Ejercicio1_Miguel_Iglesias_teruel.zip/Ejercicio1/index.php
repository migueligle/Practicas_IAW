<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>practica1</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/light.css">
</head>
<body>
<h1>índice de la practica</h1>
<ul>
    <li><a href="ejercicio1.php">ejercicio1 (claro/oscuro)</a></li>
    <li><a href="ejercicio2.php">ejercicio2 (texto infinito)</a></li>
    <li><a href="ejercicio3.php">ejercicio3 (patrón tipo tablero de ajedrez)</a></li>
</ul>
</body>
</html>