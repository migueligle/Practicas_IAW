<?php
//comprobación de existencia de datos por post
if (isset($_POST["texto"]) && strlen($_POST["texto"] > 0)) {
    $texto = $_POST["texto"];


}
?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/water.css@2/out/light.css">
</head>
<body>
<h1>Texto interminable</h1>
<form action="ejercicio2.php" method="post">
    <label for="texto">Texto</label>
    <textarea name="texto" id="texto" cols="30" rows="10"></textarea>
    <button>Enviar</button>

    <div>
        <?php

        //sacar por pantalla todos los registros que vienen por post
        //intento de realizar un array para alamacenar todos los textos que vengan por post
        // y con el bucle foreach sacarlos pero solo saca el dato actual enviado

        if (isset($texto)) {
            $textos = array($texto);

            foreach ($textos as $tex => $valor) {
                echo " $valor <br>";
            }
            //echo $textoo;
        }


        ?>

    </div>

</body>
</html>
